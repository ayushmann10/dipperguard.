# DIPPERGUARD — free website + mobile-friendly PWA

This is a static website for presenting an existing automatic headlight dipper model. It includes an interactive JavaScript simulation, responsive mobile layout, a basic installable-PWA setup, and gallery placeholders.

## Cost
Designed to run at $0 / ₹0 using free static hosting and a free GitHub account. A custom domain is optional and normally costs money. No paid API, database, framework, or subscription is needed.

## Files
- `index.html` — the full website, styles, and simulation
- `manifest.json` — metadata for the installable web-app experience
- `sw.js` — basic offline cache
- `assets/icon.svg` — app icon

## Test it on your computer
1. Unzip the folder.
2. Open `index.html` in Chrome/Edge/Firefox.
3. Scroll to “Try the dipper simulation” and click the two scenario buttons.
4. Note: browser installation and service-worker/offline features generally require HTTPS hosting or a local development server; they may not work when opening the file directly.

## Publish it free with GitHub Pages
1. Sign in or create an account at https://github.com/.
2. Create a **new public repository** named `dipperguard`.
3. Upload `index.html`, `manifest.json`, and `sw.js` to the repository's top level. Upload the `assets` folder too.
4. Open repository **Settings** → **Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Select branch `main` and folder `/ (root)`, then press **Save**.
7. Wait for the deployment to finish. Your URL will look like:
   `https://YOUR-USERNAME.github.io/dipperguard/`
   Replace `YOUR-USERNAME` with your GitHub username. Do not assume the site is live until GitHub Pages shows the published URL.
8. Open the URL on your phone. In your browser menu, choose **Install app** or **Add to Home Screen** if offered.

Official guide: https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site

## Add your actual model photographs
1. Copy your photos into the `assets` folder and name them `front.jpg`, `circuit.jpg`, and `side.jpg`.
2. In `index.html`, find the `Project gallery` section.
3. Replace each placeholder `<div class="photo">...` with an image, for example:
   `<div class="photo"><img src="assets/front.jpg" alt="Front view of the automatic dipper prototype"></div>`
4. Commit/save the changes and upload them to the repository. GitHub Pages will republish automatically.

## Important technical truth
This website does **not** connect to the physical LDR/relay circuit, receive real sensor values, control headlights, or run an AI model. The beam changes shown are simulated in JavaScript. A real-time hardware dashboard would require a data connection and a compatible controller, which are intentionally excluded because the physical model must remain unchanged.

## Updating the site
Edit `index.html` in a text editor or directly in GitHub. After changes, commit/save the file. If an old version appears, refresh the page or clear the browser cache.
